from django.contrib import admin
from .models import CustomImage, Project

admin.site.register(CustomImage)
admin.site.register(Project)
# Register your models here.

